from sense_hat import SenseHat
sense = SenseHat()
sense.show_message("Zoey and Will are stinky. Zoey and Will need a bath.")

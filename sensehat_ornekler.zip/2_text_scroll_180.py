from sense_hat import SenseHat
sense = SenseHat()
sense.set_rotation(180)
sense.show_message("Zoey and Will are stinky. Zoey and Will need a bath.")
